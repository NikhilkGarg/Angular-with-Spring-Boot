package com.core.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.core.app.dao.StaffRepo;
import com.core.app.module.Staff;

@RestController
@CrossOrigin(origins="http://localhost:4200",allowedHeaders="*")
public class StaffController {

	@Autowired
	private StaffRepo sRepo;
	
	@GetMapping("/staffs")
	public ResponseEntity<List<Staff>> getStaffs(){
		ResponseEntity<List<Staff>> rp = new ResponseEntity<>(sRepo.findAll(),HttpStatus.OK);
		return rp;
	}
	
	@RequestMapping("/staff/login/{staffUserName}&{staffPassword}")
	public ResponseEntity<Optional<Staff>> getStaffValidate(@PathVariable String staffUserName,@PathVariable String staffPassword) 
	{
		ResponseEntity<Optional<Staff>> rp = new ResponseEntity<>(sRepo.validateStaff(staffUserName,staffPassword),HttpStatus.OK);
		System.out.println("in login :    "+staffUserName+ "     "+staffPassword);
		return rp;
	}

	@GetMapping("/staff/{staffID}")
	public ResponseEntity<Optional<Staff>> getStaffById(@PathVariable Integer staffID) {
		ResponseEntity<Optional<Staff>> rp = new ResponseEntity<>(sRepo.findById(staffID),HttpStatus.OK);
		return rp;
	}

	@DeleteMapping("/staff/{staffID}")
	public boolean deleteStaff(@PathVariable Integer staffID) {
		sRepo.deleteById(staffID);
		return true;
	}
	
	@PostMapping("/staff")
	public ResponseEntity<Staff> createStaff(@RequestBody Staff staff){
		ResponseEntity<Staff> rp = new ResponseEntity<Staff>(sRepo.save(staff),HttpStatus.OK);
		return rp;
	}

	@PutMapping("/staff")
	public ResponseEntity<Staff> updateStaff(@RequestBody Staff staff){
		ResponseEntity<Staff> rp = new ResponseEntity<Staff>(sRepo.save(staff),HttpStatus.OK);
		return rp;
	}
	
}
